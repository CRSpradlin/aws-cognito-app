const errorRepository = require('/opt/errorRepository');

class socketAuthorizer {
    
    constructor(cognitoService, createAPIResponse, event) {
        this.cognitoService = cognitoService;
        this.createAPIResponse = createAPIResponse;
        this.token = event.headers.Authorization;
        this.connectionId = event.requestContext.connectionId;
    }

    handler = async () => {
        try {
            if (this.token !== undefined) {
                await this.cognitoService.getUser(this.token);
                //add connection id to user
            } else {
                throw errorRepository.createError(403);
            }
            
            return this.createAPIResponse.Ok();
        } catch (error) {
            let newError = error;

            if (!error.errorCode) {
                newError = errorRepository.createError(403, error);
            }

            return this.createAPIResponse.Error(newError, newError.errorCode);
        }
    }
}

exports.socketAuthorizerService = (deps) => {
    return new socketAuthorizer(deps.cognitoService, deps.createAPIResponse, deps.event);   
}

exports.handler = async (event) => {
    const cognitoService = require('/opt/cognitoService');
    const createAPIResponse = require('/opt/createAPIResponse');
    const deps = {
        cognitoService,
        createAPIResponse,
        event
    };

    return await exports.socketAuthorizerService(deps).handler();
}