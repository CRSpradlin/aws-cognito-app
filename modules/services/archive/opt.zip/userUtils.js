class userUtils {

    constructor(uuid, dynamoDB, cognitoService) {
        this.uuid = uuid.v4;
        this.dynamoDB = dynamoDB;
        this.cognitoService = cognitoService;
    }

    createUser = async (username, password, email) => {
        const profile = this.uuid();

        await this.dynamoDB.put('UserData', {
            profile: profile,
            email: email,
            conversations: [],
            sessions: []
        });
        
        const userAttributes = [
            {Name: 'email', Value: email},
            {Name: 'profile', Value: profile}
        ];

        const response = await this.cognitoService.createUser(username, password, userAttributes);
        
        return response;
    }

    getUser = async (userProfile) => {
        const userKey = {
            profile: userProfile
        };
        const user = await this.dynamoDB.get('UserData', userKey);

        return user;
    }

    // TODO: DELETE, FOR REFERENCE ONLY
    // createConvo = async (ownerProfile, members, name = 'Group Chat') => {

    //     const additionalConfig = {
    //         ExpressionAttributeNames: {
    //             '#conversations': 'conversations'
    //         },
    //         ExpressionAttributeValues: {
    //             ':array': [newConvo.id],
    //             ':empty_list': []
    //         }
    //     };

    //     // TODO: would need to upsentDate every member in the conversation
    //     // TODO: OR send requests to people to confirm to be in the conversation
    //     await this.dynamoDB.update('UserData', {profile: ownerProfile}, 'set #conversations = list_append(if_not_exists(#conversations, :empty_list), :array)', additionalConfig);

    //     return newConvo;
    // }

    addUserSession = async (userProfile, connectionId) => {
        const item = {
            connectionId,
            userProfile
        }

        return await this.dynamoDB.put('SocketData', item);
    }

    removeUserSession = async (connectionId) => {
        const key = {
            connectionId
        };

        return await this.dynamoDB.delete('SocketData', key);
    }
}

exports._userUtilsService = (deps) => {
    return new userUtils(deps.uuid, deps.dynamoDB, deps.cognitoService);
}

exports.default = () => {
    const uuid = require('uuid');
    const dynamoDB = require('./dynamoService');
    const cognitoService = require('./cognitoService');

    const deps = {
        uuid: uuid,
        dynamoDB: dynamoDB,
        cognitoService: cognitoService    
    };

    return exports._userUtilsService(deps);
}
